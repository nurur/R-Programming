Question 1:
getStockPrices.R         
getStockPrices.py        



Question 2:
tweetBeerAll.R


Question 3:
scrapUnivData.R
scrapUnivData.csv
scrapUnivData.pdf 
scrapUnivData.py 
